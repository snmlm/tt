package com.taotao.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.taotao.common.pojo.EUDataGridResult;
import com.taotao.common.pojo.TaotaoResult;
import com.taotao.pojo.TbItem;
import com.taotao.service.ItemService;

/**
 * 商品controller
 * @author	w.x.y
 * @date	2017年2月4日上午10:22:02
 * @version 1.0
 */
@Controller
public class ItemController {

	@Autowired
	private ItemService itemService;
	
	/**
	 * 获取单个商品信息
	 * 
	 * @author w.x.y
	 * @date 
	 * @Description (TODO这里用一句话描述这个方法的作用)
	 * @param itemId
	 * @return
	 */
	@RequestMapping("/item/{itemId}")
	@ResponseBody
	public TbItem getItemById(@PathVariable Long itemId) {
		TbItem tbItem = itemService.getTbItemById(itemId);
		return tbItem;
	}
	
	/**
	 * 获取商品列表操作
	 * 
	 * @author w.x.y
	 * @date 
	 * @Description (TODO这里用一句话描述这个方法的作用)
	 * @param page
	 * @param rows
	 * @return
	 */
	@RequestMapping("/item/list")
	@ResponseBody
	public EUDataGridResult getItemList(Integer page, Integer rows) {
		EUDataGridResult result = itemService.getItemList(page, rows);
		return result;
	}
	
	/**
	 * 商品保存操作
	 * 
	 * @author w.x.y
	 * @date 
	 * @Description (TODO这里用一句话描述这个方法的作用)
	 * @param item
	 * @param desc
	 * @param itemParams
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/item/save", method= RequestMethod.POST)
	@ResponseBody
	private TaotaoResult createItem(TbItem item, String desc, String itemParams)throws Exception{
		TaotaoResult taotaoResult = itemService.createItem(item, desc, itemParams);
		return taotaoResult;
	}

}
