package com.taotao.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.taotao.common.pojo.EUDataGridResult;
import com.taotao.common.pojo.TaotaoResult;
import com.taotao.pojo.TbItemParam;
import com.taotao.service.ItemParamService;

/**
 * 规格参数Controller
 *  
 * @author w.x.y
 * @date 
 */
@Controller
@RequestMapping("/item/param")
public class ItemParamController {
	@Autowired
	private ItemParamService itemParamService;
	
	/**
	 * 查询出所有的参数列表
	 * 
	 * @author w.x.y
	 * @date 20170402
	 * @Description 
	 * @param page
	 * @param rows
	 * @return
	 */
	@RequestMapping("/list")
	@ResponseBody
	public EUDataGridResult getItemList(Integer page, Integer rows) {
		EUDataGridResult result = itemParamService.getItemParamList(page, rows);
		return result;
	}
	
	/**
	 * 判断规格参数是否已经添加
	 * 
	 * @author w.x.y
	 * @date 20170402
	 * @param itemCatId
	 * @return
	 */
	@RequestMapping("/query/itemcatid/{itemCatId}")
	@ResponseBody
	public TaotaoResult getItemParamByCid(@PathVariable Long itemCatId) {
		TaotaoResult result = itemParamService.getItemParamByCid(itemCatId);
		return result;
	}
	
	/**
	 * 规格参数 - 保存操作
	 * 
	 * @author w.x.y
	 * @date 
	 * @Description (TODO这里用一句话描述这个方法的作用)
	 * @param cid
	 * @param paramData
	 * @return
	 */
	@RequestMapping("/save/{cid}")
	@ResponseBody
	public TaotaoResult insertItemParam(@PathVariable Long cid, String paramData){
		TbItemParam tbItemParam = new TbItemParam();
		tbItemParam.setItemCatId(cid);
		tbItemParam.setParamData(paramData);
		TaotaoResult result = itemParamService.insertItemParam(tbItemParam);
		return result;
	}
	
	/**
	 * 通过id删除规格参数 
	 * 
     * @author w.x.y
     * @date 
	 * @Description (TODO这里用一句话描述这个方法的作用)
	 * @param cid
	 * @return
	 */
	@RequestMapping("/delete")
	@ResponseBody
	public TaotaoResult deleteItemParam(@RequestParam("ids") String ids){
	    String[] idsArr = ids.split(",");
	    Long[] cids = new Long[idsArr.length];
	    for(int i=0; i<idsArr.length; i++){
	        cids[i] = Long.parseLong(idsArr[i]);
	    }
	    
	    TaotaoResult result;
        try {
            result = itemParamService.deleteItemParams(cids);
            return result;
        } catch (Exception e) {
            return new TaotaoResult(500, e.getMessage(), "删除失败");
        }
	    
	}
	

}
