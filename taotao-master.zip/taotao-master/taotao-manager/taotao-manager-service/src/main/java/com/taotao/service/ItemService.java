package com.taotao.service;

import com.taotao.common.pojo.EUDataGridResult;
import com.taotao.common.pojo.TaotaoResult;
import com.taotao.pojo.TbItem;

/**
 * 商品service
 * 
 * @ClassName ItemService
 * @Description TODO(这里用一句话描述这个类的作用)
 * @author w.x.y
 * @Date 2017年4月9日 下午9:31:48
 * @version 1.0.0
 */
public interface ItemService {
	
    /**
     * 通过id获取一个商品信息
     * 
     * @author w.x.y
     * @Date 2017年4月9日 下午9:32:13
     * @version 1.0.0
     * @param itemId
     * @return
     */
	TbItem getTbItemById(long itemId);
	
	/**
	 * 获取商品信息列表
	 * @author w.x.y
	 * @Date 2017年4月9日 下午9:33:24
	 * @version 1.0.0
	 * @param page
	 * @param rows
	 * @return
	 */
	EUDataGridResult getItemList(int page, int rows);
	
	/**
	 * 创建商品信息
	 * @author w.x.y
	 * @Date 2017年4月9日 下午9:33:34
	 * @version 1.0.0
	 * @param tbItem
	 * @param itemDesc
	 * @param itemParam
	 * @return
	 * @throws Exception
	 */
	TaotaoResult createItem(TbItem tbItem, String itemDesc, String itemParam) throws Exception;

}
