package com.taotao.service;

import java.util.List;
import com.taotao.common.pojo.EUTreeNode;

/**
 * 商品类目Service
 * @ClassName ItemCatListService
 * @Description TODO(这里用一句话描述这个类的作用)
 * @author w.x.y
 * @Date 2017年4月9日 下午9:36:01
 * @version 1.0.0
 */
public interface ItemCatListService {
	
    /**
     * 获取所有商品类目
     * @author w.x.y
     * @Date 2017年4月9日 下午9:38:15
     * @version 1.0.0
     * @param parentId
     * @return
     */
	List<EUTreeNode> getCatList(long parentId);
}
