package com.taotao.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.taotao.common.pojo.EUDataGridResult;
import com.taotao.common.pojo.TaotaoResult;
import com.taotao.mapper.TbItemParamMapper;
import com.taotao.pojo.TbItemParam;
import com.taotao.pojo.TbItemParamExample;
import com.taotao.pojo.TbItemParamExample.Criteria;
import com.taotao.service.ItemParamService;
import com.taotao.vo.ItemParam;

/**
 * 商品规格参数
 * @ClassName ItemParamServiceImpl
 * @Description TODO(这里用一句话描述这个类的作用)
 * @author w.x.y
 * @Date 2017年4月9日 下午9:42:29
 * @version 1.0.0
 */
@Service
public class ItemParamServiceImpl implements ItemParamService {

	@Autowired
	private TbItemParamMapper tbItemParamMapper;
	
	/**
	 * 
	 * @author w.x.y
	 * @Date 2017年4月9日 下午9:42:35
	 * @version 1.0.0
	 * @param page
	 * @param rows
	 * @return
	 */
	@Override
	public EUDataGridResult getItemParamList(int page, int rows) {
		PageHelper.startPage(page, rows);
		List<ItemParam> list = tbItemParamMapper.getTbItemParam();
		EUDataGridResult result = new EUDataGridResult();
		result.setRows(list);
		PageInfo<ItemParam> pageInfo = new PageInfo<>(list);
		result.setTotal(pageInfo.getTotal());
		return result;		
	}

	/**
	 * 
	 * @author w.x.y
	 * @Date 2017年4月9日 下午9:42:38
	 * @version 1.0.0
	 * @param cid
	 * @return
	 */
	@Override
	public TaotaoResult getItemParamByCid(long cid) {
		TbItemParamExample tbItemParamExample = new TbItemParamExample();
		Criteria criteria = tbItemParamExample.createCriteria();
		criteria.andItemCatIdEqualTo(cid);
		List<TbItemParam> list = tbItemParamMapper.selectByExampleWithBLOBs(tbItemParamExample);      // 查询规格参数的时候需要使用大文本列
		if(list != null && list.size() > 0) {
			return TaotaoResult.ok(list.get(0));
		}
		return TaotaoResult.ok();
	}

	/**
	 * 
	 * @author w.x.y
	 * @Date 2017年4月9日 下午9:42:42
	 * @version 1.0.0
	 * @param tbItemParam
	 * @return
	 */
	@Override
	public TaotaoResult insertItemParam(TbItemParam tbItemParam) {
		tbItemParam.setCreated(new Date());
		tbItemParam.setUpdated(new Date());
		tbItemParamMapper.insert(tbItemParam);
		return TaotaoResult.ok();
	}

	/**
	 * 通过id删除某一个规格参数
	 * @author w.x.y
	 * @Date 2017年4月9日 下午9:42:50
	 * @version 1.0.0
	 * @param cids
	 * @return
	 * @throws Exception
	 */
    @Override
    public TaotaoResult deleteItemParams(Long[] cids) throws Exception {
        try {
            for (long cid : cids) {
                tbItemParamMapper.deleteByPrimaryKey(cid);
            } 
            return TaotaoResult.ok();
        } catch (Exception e) {
            return new TaotaoResult(500, e.getMessage(), "删除失败");
        }
        
    }
	
	
	
	
	
	

}
