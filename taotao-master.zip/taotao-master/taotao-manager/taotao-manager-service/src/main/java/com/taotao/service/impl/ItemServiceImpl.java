package com.taotao.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.taotao.common.extra.enums.ItemStatus;
import com.taotao.common.pojo.EUDataGridResult;
import com.taotao.common.pojo.TaotaoResult;
import com.taotao.common.utils.IDUtils;
import com.taotao.mapper.TbItemDescMapper;
import com.taotao.mapper.TbItemMapper;
import com.taotao.mapper.TbItemParamItemMapper;
import com.taotao.pojo.TbItem;
import com.taotao.pojo.TbItemDesc;
import com.taotao.pojo.TbItemExample;
import com.taotao.pojo.TbItemExample.Criteria;
import com.taotao.pojo.TbItemParamItem;
import com.taotao.service.ItemService;


/**
 * 商品管理Service
 * <p>Title: ItemServiceImpl</p>
 * <p>Description: </p>
 * <p>Company: http://www.posun.cn/</p> 
 * @author	ShawnWang
 * @date	2017年2月4日上午10:09:15
 * @version 1.0
 */
@Service
public class ItemServiceImpl implements ItemService {

	@Autowired
	private TbItemMapper itemMapper;
	
	@Autowired
	private TbItemDescMapper itemDescMapper;
	
	@Autowired
	private TbItemParamItemMapper itemParamItemMapper;
	
	/**
	 * 
	 * @author w.x.y
	 * @Date 2017年4月9日 下午9:40:34
	 * @version 1.0.0
	 * @param itemId
	 * @return
	 */
	@Override
	public TbItem getTbItemById(long itemId) {
		
		// 方法1：根据主键查询
		/*TbItem tbItem = itemMapper.selectByPrimaryKey(itemId);*/
		
		// 方法2：使用TbItemExample添加查询条件
		TbItemExample tbItemExample = new TbItemExample();
		Criteria createCriteria = tbItemExample.createCriteria();
		createCriteria.andIdEqualTo(itemId);		
		List<TbItem> list = itemMapper.selectByExample(tbItemExample);
		if(list != null && list.size() > 0) {
			return list.get(0);
		}
		
		return null;
	}
	
	/**
	 * 
	 * @author w.x.y
	 * @Date 2017年4月9日 下午9:41:02
	 * @version 1.0.0
	 * @param page
	 * @param rows
	 * @return
	 */
	@Override
	public EUDataGridResult getItemList(int page, int rows) {
		//查询商品列表
		TbItemExample example = new TbItemExample();
		//分页处理
		PageHelper.startPage(page, rows);
		List<TbItem> list = itemMapper.selectByExample(example);
		//创建一个返回值对象
		EUDataGridResult result = new EUDataGridResult();
		result.setRows(list);
		//取记录总条数
		PageInfo<TbItem> pageInfo = new PageInfo<>(list);
		result.setTotal(pageInfo.getTotal());
		return result;
	}

	/***
	 * 事务的回滚：事务全部交个spring来进行处理，当spring遇到异常时就会回滚。所以有异常的时候就要抛出（运行期异常runtimeException）。
	 */
	/**
	 * 
	 * @author w.x.y
	 * @Date 2017年4月9日 下午9:41:10
	 * @version 1.0.0
	 * @param tbItem
	 * @param itemDesc
	 * @param itemParam
	 * @return
	 * @throws Exception
	 */
	@Override
	public TaotaoResult createItem(TbItem tbItem, String itemDesc, String itemParam) throws Exception{
	    
	    Long itemId = IDUtils.genItemId();
	    tbItem.setId(itemId);
	    tbItem.setStatus(ItemStatus.NORMAL.getCode());
	    tbItem.setCreated(new Date());
	    tbItem.setUpdated(new Date());
        //插入到数据库
        itemMapper.insert(tbItem);
        //添加商品描述信息
        TaotaoResult result = insertItemDesc(itemId, itemDesc);
        if (result.getStatus() != 200) {
            throw new Exception();
        }
        //添加规格参数
        result = insertItemParamItem(itemId, itemParam);
        if (result.getStatus() != 200) {
            throw new Exception();
        }
        return TaotaoResult.ok();
	}
	
	/**
	 * 商品描述信息保存
	 * @author w.x.y
	 * @Date 2017年4月9日 下午9:41:54
	 * @version 1.0.0
	 * @param itemId
	 * @param desc
	 * @return
	 */
	private TaotaoResult insertItemDesc(Long itemId, String desc) {
        TbItemDesc itemDesc = new TbItemDesc();
        itemDesc.setItemId(itemId);
        itemDesc.setItemDesc(desc);
        itemDesc.setCreated(new Date());
        itemDesc.setUpdated(new Date());
        itemDescMapper.insert(itemDesc);
        return TaotaoResult.ok();
    }
	
	/**
	 * 添加商品规格参数
	 * @author w.x.y
	 * @Date 2017年4月9日 下午9:42:03
	 * @version 1.0.0
	 * @param itemId
	 * @param itemParam
	 * @return
	 */
	private TaotaoResult insertItemParamItem(Long itemId, String itemParam){
	    TbItemParamItem itemParamItem = new TbItemParamItem();
	    itemParamItem.setItemId(itemId);
	    itemParamItem.setParamData(itemParam);
	    itemParamItem.setCreated(new Date());
	    itemParamItem.setUpdated(new Date());
	    itemParamItemMapper.insert(itemParamItem);
	    return TaotaoResult.ok();
	}
	
	

}
