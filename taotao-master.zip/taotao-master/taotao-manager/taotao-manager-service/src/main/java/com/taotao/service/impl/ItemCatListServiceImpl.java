package com.taotao.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import com.taotao.common.pojo.EUTreeNode;
import com.taotao.mapper.TbItemCatMapper;
import com.taotao.pojo.TbItemCat;
import com.taotao.pojo.TbItemCatExample;
import com.taotao.pojo.TbItemCatExample.Criteria;
import com.taotao.service.ItemCatListService;

/**
 * 商品类目service
 * @ClassName ItemCatListServiceImpl
 * @Description TODO(这里用一句话描述这个类的作用)
 * @author w.x.y
 * @Date 2017年4月9日 下午9:43:20
 * @version 1.0.0
 */
@Service
public class ItemCatListServiceImpl implements ItemCatListService {

	@Autowired
	private TbItemCatMapper itemCatMapper;
	
	/**
	 * 
	 * @author w.x.y
	 * @Date 2017年4月9日 下午9:43:29
	 * @version 1.0.0
	 * @param parentId
	 * @return
	 */
	@Override
	public List<EUTreeNode> getCatList(long parentId) {
		TbItemCatExample tbItemCatExample = new TbItemCatExample();
		Criteria criteria = tbItemCatExample.createCriteria();
		criteria.andParentIdEqualTo(parentId);
		List<TbItemCat> tbItemCats = itemCatMapper.selectByExample(tbItemCatExample);
		List<EUTreeNode> euTreeNodes = new ArrayList<>();
		
		for (TbItemCat tbItemCat : tbItemCats) {
			EUTreeNode euTreeNode = new EUTreeNode();
			euTreeNode.setId(tbItemCat.getId());
			euTreeNode.setText(tbItemCat.getName());
			euTreeNode.setState(tbItemCat.getIsParent()?"closed":"open");
			euTreeNodes.add(euTreeNode);			
		}
		
		return euTreeNodes;
	}

	
}
