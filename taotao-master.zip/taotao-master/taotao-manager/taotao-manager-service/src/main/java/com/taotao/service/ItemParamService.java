package com.taotao.service;

import com.taotao.common.pojo.EUDataGridResult;
import com.taotao.common.pojo.TaotaoResult;
import com.taotao.pojo.TbItemParam;

/**
 * 商品规格参数Service
 * @ClassName ItemParamService
 * @Description TODO(这里用一句话描述这个类的作用)
 * @author w.x.y
 * @Date 2017年4月9日 下午9:34:04
 * @version 1.0.0
 */
public interface ItemParamService {
    
    /**
     * 获取商品规格参数列表
     * @author w.x.y
     * @Date 2017年4月9日 下午9:34:28
     * @version 1.0.0
     * @param page
     * @param rows
     * @return
     */
	EUDataGridResult getItemParamList(int page, int rows);
	
	/**
	 * 通过商品规格参数id获取规格参数
	 * @author w.x.y
	 * @Date 2017年4月9日 下午9:34:40
	 * @version 1.0.0
	 * @param cid
	 * @return
	 */
	TaotaoResult getItemParamByCid(long cid);
	
	/**
	 * 保存一个商品规格参数
	 * @author w.x.y
	 * @Date 2017年4月9日 下午9:35:08
	 * @version 1.0.0
	 * @param tbItemParam
	 * @return
	 */
	TaotaoResult insertItemParam(TbItemParam tbItemParam);
	
	/**
	 * 一次性删除多个商品规格参数
	 * @author w.x.y
	 * @Date 2017年4月9日 下午9:35:29
	 * @version 1.0.0
	 * @param cids
	 * @return
	 * @throws Exception
	 */
	TaotaoResult deleteItemParams(Long[] cids) throws Exception;
}
