package com.taotao.service;

import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

/**
 * 图片Service
 * @ClassName PictureService
 * @Description TODO(这里用一句话描述这个类的作用)
 * @author w.x.y
 * @Date 2017年4月9日 下午9:27:27
 * @version 1.0.0
 */
public interface PictureService {
    
    /**
     * 图片上传
     * 
     * @author w.x.y
     * @Date 2017年4月9日 下午9:31:18
     * @version 1.0.0
     * @param uploadFile
     * @return
     */
	Map uploadFile(MultipartFile uploadFile);
}
