package com.taotao.common.extra.enums;

/**
 * 商品状态的枚举类
 * @ClassName ItemStatus
 * @Description TODO(这里用一句话描述这个类的作用)
 * @author w.x.y
 * @Date 2017年4月9日 下午9:44:05
 * @version 1.0.0
 */
public enum ItemStatus {
    ERROR((byte)0, "错误"),
    NORMAL((byte)1, "正常"),
    UNDERCARRIAGE((byte)2, "下架"),
    DELETED((byte)3, "删除");
    
    private Byte code;
    private String name;
    
    public Byte getCode() {
        return code;
    }

    public void setCode(Byte code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    private ItemStatus(Byte code, String name){
        this.setCode(code);
        this.setName(name);
    }
    
    public static Byte getCodeByName(String name){
        if(name==null || name=="" || "".equals(name)){
            return null;
        }
        for (ItemStatus temp : ItemStatus.values()) {
            if (temp.getName().equals(name)) {
                return temp.getCode();
            }
        }
        return null;
    }
    
    public static String getNameByCode(Byte code){
        for (ItemStatus temp : ItemStatus.values()) {
            if (temp.getCode().equals(code)) {
                return temp.getName();
            }
        }
        return null;
    }

}
