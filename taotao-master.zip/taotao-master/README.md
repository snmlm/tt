
# 淘淘商城
***
## 概述
淘淘商城是传智播客的一个录制视频学习项目，作者通过观看视频加上自己动手实践操作弄的一个项目。此项目主要可以用于大学生软件工程的毕业设计、软件工作人员的分布式学习。

此版本是第一次上传版本，后面会不定时更新，如有疑问可以联系我（1129432705@qq.com）。

## 技术选型
* spring+springMVC+mybatis+maven
* vsftp
* nginx
* redis
* ...

## 开发工具：
* eclipse-mars
* jdk1.8
* maven上面的tomcat插件
* mysql
* ...

## 项目的搭建
* 项目的导入
	项目的导入跟平常的项目导入一样。只不过是要将taotao-parent、taotao-common、taotao-manager依次导入即可。
* 数据的导入
	通过搭建centos6.4服务器，然后在Windows平台使用navicat进行连接导入即可。

## 项目的运行
* 后面会写教程









